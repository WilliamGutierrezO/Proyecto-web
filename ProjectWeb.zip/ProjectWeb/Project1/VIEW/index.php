<?php
// Check if the user is logged in, if not then redirect him to login page
// if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !==
// true){
// header("location: login.php");
// exit;
// }


require_once './header.php';
include '../MODEL/config.php';

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="./CSS/style1.css">
    <link rel="stylesheet" href="./CSS/index1.css">
    <link rel="stylesheet" href="./CSS/modal.css">

</head>

<body>

    <?php
    //   require_once 'carrito_sid.php';

    ?>





    <div class="container">
        <!-- Modal -->
        <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <br>
                        <h1 class="modal-title titulo"><img src="./Imagenes/1f355.png" alt="">Arme su Pizza!</h1>
                    </div>
                    <div class="modal-body">
                        <form action="">
                            <div>
                                <h1 class="titulo">Seleccione tipo de Masa</h1>
                                <br>
                                <div class="CheckMasa" id="form1">
                                    <label><input type="radio" name="masa"> Masa Gruesa</label>
                                    <label><input type="radio" name="masa"> Masa Delgada</label>
                                </div>
                            </div>

                            <h1 class="titulo">Seleccione Ingredientes </h1>
                            <div class="CheckOrden" id="form2">
                                Tomate <input type="checkbox" name="check1" onchange="limitar('form2',this)">
                                Jamon <input type="checkbox" name="check2" onchange="limitar('form2',this)">
                                Peperoni<input type="checkbox" name="check3" onchange="limitar('form2',this)">
                                Albahaca<input type="checkbox" name="check4" onchange="limitar('form2',this)">
                                Choclo <input type="checkbox" name="check5" onchange="limitar('form2',this)">
                                Piña <input type="checkbox" name="check6" onchange="limitar('form2',this)">
                                Camarones<input type="checkbox" name="check7" onchange="limitar('form2',this)">
                                Tocino <input type="checkbox" name="check8" onchange="limitar('form2',this)">
                                Seitan <input type="checkbox" name="check9" onchange="limitar('form2',this)">
                                Tofu <input type="checkbox" name="check10" onchange="limitar('form2',this)">
                                Albacora<input type="checkbox" name="check11" onchange="limitar('form2',this)">

                            </div>
                            <input class="submit" type="submit" value="Enviar al carrito">
                        </form>


                    </div>


                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                </div>
            </div>
        </div>
    </div>




    <main>
    <section  class="contenedor">
            
            <div class="titulo divHeader">
                Tambien lleve solamente un trozo por
                <br>$2000
                <img src="./Imagenes/trozop.png" alt="">
                <br>
                <p></p>
            </div>

            <div class="letras pizza">
                <?php
                $query = $link->query("SELECT * FROM pizza_preparada WHERE nombre_pizza = 'Napolitana' ORDER BY id_pizza DESC LIMIT 10");
                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) { ?>
                <img src="<?php echo $row['Img']; ?>" alt="">
                <br>
                <br>Pizza <?php echo $row["nombre_pizza"]; ?>
                <br>
                <?php echo '$' . $row["precio_pizza"] . ' CLP'; ?>
                <br><a class="btn btn-success" href="../MODEL/cartAction.php?action=addToCart&id=<?php echo $row["id_pizza"]; ?>">Añadir al carrito</a>
                <?php 
                    }
                }
                ?>
            </div>


            <div class="letras pizza">
                <?php
                $query = $link->query("SELECT * FROM pizza_preparada WHERE nombre_pizza = 'Marinera' ORDER BY id_pizza DESC LIMIT 10");
                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) { ?>
                <img src="<?php echo $row['Img']; ?>" alt="">
                <br>
                <br>Pizza <?php echo $row["nombre_pizza"]; ?>
                <br>
                <?php echo '$' . $row["precio_pizza"] . ' CLP'; ?>
                <br><a class="btn btn-success" href="../MODEL/cartAction.php?action=addToCart&id=<?php echo $row["id_pizza"]; ?>">Añadir al carrito</a>
                <?php 
                    }
                }
                ?>
            </div>
            <div class="letras pizza">
                <?php
                $query = $link->query("SELECT * FROM pizza_preparada WHERE nombre_pizza = 'Española' ORDER BY id_pizza DESC LIMIT 10");
                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) { ?>
                <img src="<?php echo $row['Img']; ?>" alt="">
                <br>
                <br>Pizza  <?php echo $row["nombre_pizza"]; ?>
                <br>
                <?php echo '$' . $row["precio_pizza"] . ' CLP'; ?>
                
                <br><a class="btn btn-success" href="../MODEL/cartAction.php?action=addToCart&id=<?php echo $row["id_pizza"]; ?>">Añadir al carrito</a>
                <?php 
                    }
                }
                ?>
            </div>
            <!-- Modal Button-->
            <button type="button" class="pizza" data-toggle="modal" data-target="#myModal">
                <div class="letras ">
                    <br><br>
                    <img src="./Imagenes/armatupizza.png" alt="">
                    <br><br><br>
                    Arme su Pizza
                </div>
            </button>

            <div class="letras pizza">
                <?php
                $query = $link->query("SELECT * FROM pizza_preparada WHERE nombre_pizza = 'Peperonni' ORDER BY id_pizza DESC LIMIT 10");
                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) { ?>
                <img src="<?php echo $row['Img']; ?>" alt="">
                <br>
                <br><?php echo $row["nombre_pizza"]; ?>
                <br>
                <?php echo '$' . $row["precio_pizza"] . ' CLP'; ?>
                <br><a class="btn btn-success" href="../MODEL/cartAction.php?action=addToCart&id=<?php echo $row["id_pizza"]; ?>">Añadir al carrito</a>
                <?php 
                    }
                }
                ?>
            </div>
            <div class="letras pizza">
                <?php
                $query = $link->query("SELECT * FROM pizza_preparada WHERE nombre_pizza = 'Margarita' ORDER BY id_pizza DESC LIMIT 10");
                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) { ?>
                <img src="<?php echo $row['Img']; ?>" alt="">
                <br>
                <br><?php echo $row["nombre_pizza"]; ?>
                <br>
                <?php echo '$' . $row["precio_pizza"] . ' CLP'; ?>
                <br><a class="btn btn-success" href="../MODEL/cartAction.php?action=addToCart&id=<?php echo $row["id_pizza"]; ?>">Añadir al carrito</a>
                <?php 
                    }
                }
                ?>
            </div>
            <div class="letras pizza">
                <?php
                $query = $link->query("SELECT * FROM pizza_preparada WHERE nombre_pizza = 'Hawaiiana' ORDER BY id_pizza DESC LIMIT 10");
                if ($query->num_rows > 0) {
                    while ($row = $query->fetch_assoc()) { ?>
                <img src="<?php echo $row['Img']; ?>" alt="">
                <br>
                <br><?php echo $row["nombre_pizza"]; ?>
                <br>
                <?php echo '$' . $row["precio_pizza"] . ' CLP'; ?>
                <br><a class="btn btn-success" href="../MODEL/cartAction.php?action=addToCart&id=<?php echo $row["id_pizza"]; ?>">Añadir al carrito</a>
                <?php 
                    }
                }
                ?>
            </div>
        </section>


    </main>


    <script src="./JS/index.js"></script>
    <script src="./JS/carrito.js"></script>
    <script src="./JS/limitar.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/32a0641e4b.js" crossorigin="anonymous"></script>
</body>

</html>