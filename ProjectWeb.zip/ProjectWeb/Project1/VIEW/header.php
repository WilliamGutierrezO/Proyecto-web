<?php session_start();
?>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="./CSS/style1.css">
<!DOCTYPE html>
<style>
    .bienvenido{
        color: white;
    }
</style>
<header class="header">

    <form class="form-login letra" method="post">
        <div class="plogin">
            <p style="color:white">
                <?php
                
                if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
                    echo '<h1 class="bienvenido">Bienvenido: ', ($_SESSION["username"]),'</h1>';
                } else {
                    echo  '<a name="alogin" href="login-view.php"><input type="button"  class="register letras" value="Login"></a>';
                }
                ?>
            </p>
        </div>
        <div>
            <?php
            if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
                echo '<a href="../CONTROLLER/logout.php"><input type="button" class="register letras" value="Log out"></a>';
            }
            ?>
        </div>
    </form>

  


    <div class="navbar">
        <div class="logo titulo">
            
            <a href="../VIEW/index.php">
                <h1><img src="./Imagenes/1f355.png" alt="">USM's Pizzas</h1>
            </a>
        </div>

        <nav>
            <ul class="navegacion titulo">
                <?php   
                if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
                    echo ' <li><a href="../VIEW/pedidos.php">Pedidos</a></li>';
                }
                ?>
                <li><a href="../VIEW/contact.php">Contacto</a></li>               
                <a href="viewCart.php" class="cart-link" title="View Cart"><i class="carrito-button w3-xxlarge carrito fa-solid fa-cart-shopping"></i></a>
            </ul>
        </nav>
    </div>

</header>
