
<?php

require_once 'header.php';


?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="./CSS/style.css">
    <link rel="stylesheet" href="./CSS/contact.css">
</head>

<body>

    <?php
    //   require_once 'carrito_sid.php';

    ?>

    <main>
        <section class="contenedor">

            <div class="divHeader">
                <h2>Direccion: USM</h2>
                <h2>Numero: +569865236542</h2>
                <h2>Correo: usmpizzas@gmail.com</h2>
            </div>
            <div class="mapa">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d53510.14423574846!2d-71.53511277076943!3d-33.0463554838654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9689deb627388a49%3A0x4fe7dead49a7bcc!2sUniversidad%20Tecnica%20Federico%20Santa%20Maria!5e0!3m2!1ses!2scl!4v1653790082537!5m2!1ses!2scl" width="1000" height="600" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>  
            </div>


        </section>
    </main>


    <script src="./JS/index.js"></script>
    <script src="./JS/carrito.js"></script>
    <script src="./JS/limitar.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/32a0641e4b.js" crossorigin="anonymous"></script>
</body>

</html>