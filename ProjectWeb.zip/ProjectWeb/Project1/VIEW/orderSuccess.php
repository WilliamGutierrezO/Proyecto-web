<?php
if(!isset($_REQUEST['id'])){
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <style>
    .container{width: 100%;padding: 50px;}
    p{color: #34a853;font-size: 18px;}
    </style>
</head>
</head>
<body>
<div class="container">
    <h1>Estado Del Pedido</h1>
    <p>Pedido Enviado correctamente, Id del pedido: <?php echo $_GET['id']; ?></p>
    <a href="index.php">Retroceder  </a>
</div>
</body>
</html>