<!DOCTYPE html>
<html lang="es">
    
    <?php
require_once 'header.php';
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="./CSS/style1.css">
    <link rel="stylesheet" href="./CSS/pedido1.css">
    
    <script>
         $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        }); 
    </script>
</head>

<body>
    <main>
        <section class="contenedor">
            <div>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mt-5 mb-3">
                                <h1 class="titulo">Detalle de Pedido</h1>
                            </div>
                            <?php
                            // Include config file
                            require_once "../CONTROLLER/config.php";
                            // Attempt select query execution
                            if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && $_SESSION["rol"] === 1) {
                                $sql = "SELECT p.*,u.nombre_user, u.telefono, u.direccion FROM pedido p, usuarios u WHERE p.id_user = u.id_user";
                            }
                            if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && $_SESSION["rol"] === 2) {
                                $idu = $_SESSION["id_user"];
                                $sql = "SELECT p.*,u.nombre_user, u.telefono, u.direccion FROM pedido p, usuarios u WHERE p.id_user = u.id_user AND p.id_user = '$idu'";
                            }
                            
                            if ($result = mysqli_query($link, $sql)) {
                                if (mysqli_num_rows($result) > 0) {
                                    echo '<table class="table table-bordered table-striped">';
                                    echo "<thead>";
                                    echo "<tr>";
                                    echo "<th>Id Pedido</th>";
                                    echo "<th>Fecha</th>";
                                    echo "<th>Medio de Pago</th>";
                                    echo "<th>Precio Total</th>";
                                    echo "<th>Nombre</th>";
                                    echo "<th>Telefono Cliente</th>";
                                    echo "<th>Direccion Cliente</th>";
                                    echo "<th>Accion</th>";
                                  
                                    echo "</tr>";
                                    echo "</thead>";
                                    echo "<tbody>";
                                    while ($row = mysqli_fetch_array($result)) {
                                        echo '<tr class="trtab">';
                                        echo "<td>" . $row['id_pedido'] . "</td>";
                                        echo "<td>" . $row['fecha'] . "</td>";
                                        echo "<td>" . $row['medio_pago'] . "</td>";
                                        echo "<td>" . $row['precio_total'] . "</td>";
                                        echo "<td>" . $row['nombre_user'] . "</td>";
                                        echo "<td>" . $row['telefono'] . "</td>";
                                        echo "<td>" . $row['direccion'] . "</td>";
                                        echo "<td>";
                                        echo '<a href="../MODEL/read.php?id=' . $row['id_pedido'] . '" class="mr-3" title="View Record"data-toggle="tooltip"><span class="fa fa-eye"></span></a>';
                                        if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true  && $_SESSION["rol"] === 1) {
                                            echo '<a href="../MODEL/delete.php?id=' . $row['id_pedido'] . '" title="Delete Record" data-toggle="tooltip"><span class="fa fa-trash"></span></a>';
                                            echo "</td>";
                                        }

                                        echo "</tr>";
                                    }
                                    echo "</tbody>";
                                    echo "</table>";
                                    // Free result set
                                    mysqli_free_result($result);
                                } else {
                                    echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
                                }
                            } else {
                                echo "Oops! Something went wrong. Please try again later.";
                            }
                            // Close connection
                            mysqli_close($link);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <script src="./JS/index.js"></script>
    <!-- <script src="./JS/carrito.js"></script> a-->
    <script src="./JS/limitar.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script> -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/32a0641e4b.js" crossorigin="anonymous"></script>
</body>

</html>