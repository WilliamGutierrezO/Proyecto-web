<?php 
require_once '../CONTROLLER/login.php'
?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../VIEW/CSS/style1.css">
    <link rel="stylesheet" href="../VIEW/CSS/index1.css">
</head>

<body>
    <div class=" wrapper">
        <h2 class="titulo">INICIAR SESION</h2>
        <p class="letras">Favor Introduzca sus datos de Inicio de Sesion</p>
        <p class="letras">No quieres iniciar sesion? click -> <a href="../VIEW/index.php">Aqui</a></p>
        <?php
        if (!empty($login_err)) {
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label class="titulo">USUARIO</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ?'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
            <div class="form-group">
                <label class="titulo">CONTRASEÑA</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="submit titulo" value="Iniciar Sesion">
            </div>
            <p class="letras">No tienes cuenta? <a href="../CONTROLLER/register.php">Registarse Ahora!</a></p>
        </form>
    </div>
</body>

</html> 