function limitar(formu,obj){
    limite=4;
    num=0;
    if (obj.checked){
        for (i=0; ele=document.getElementById(formu).children[i]; i++)
            if (ele.checked) num++;
    if (num>limite)
        obj.checked=false;
    }
} 