<?php
// Check existence of id parameter before processing further
if (isset($_GET["id"]) && !empty(trim($_GET["id"]))) {
    // Include config file
    require_once "../CONTROLLER/config.php";
    // Prepare a select statement
    $sql = "SELECT * FROM pedido WHERE id_pedido = ?";
    if ($stmt = mysqli_prepare($link, $sql)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        // Set parameters
        $param_id = trim($_GET["id"]);
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            if (mysqli_num_rows($result) == 1) {
                /* Fetch result row as an associative array. Since the result set
                contains only one row, we don't need to use while loop
                */
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                // Retrieve individual field value
                $id_ped = $row["id_pedido"];
                $fecha= $row["fecha"];
                $mediop = $row["medio_pago"];
                $pret = $row["precio_total"];
            } else {
                // URL doesn't contain valid id parameter. Redirect to error page
                header("location: error.php");
                exit();
            }
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
} else {
    // URL doesn't contain id parameter. Redirect to error page
    header("location: error.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<?php require_once '../VIEW/header.php'; ?>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../VIEW/CSS/style1.css">
    <link rel="stylesheet" href="../VIEW/CSS/contact.css">
    <style>
        .divHeader{
            font-size: 20px;
        }
    </style>
</head>

<body>
    <section class="contenedor">
        <div class="divHeader">

            <div >
                <?php
                //get rows query
                $query = $link->query("SELECT dp.id_pedido, dp.cantidad, p.precio_total,  pp.id_pizza, pp.nombre_pizza, pp.descripcion, pp.precio_pizza FROM  pizza_preparada pp 
                JOIN detalle_pedido dp on dp.id_pizza = pp.id_pizza 
                JOIN pedido p ON p.id_pedido = dp.id_pedido
                WHERE pp.id_pizza = pp.id_pizza 
                AND p.id_pedido = dp.id_pedido
                AND p.id_pedido = $id_ped
                ORDER BY id_pizza ");
                if ($query->num_rows > 0) {
                    echo '<table class="table table-bordered table-striped">';
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>Id Pedido</th>";
                    echo "<th>Nombre Pizza</th>";
                    echo "<th>Cantidad</th>";
                    echo "<th>Descripcion</th>";
                    echo "<th>Precio Unitario</th>";             
                    echo "</thead>";
                    echo "<tbody>";
                    while ($row = $query->fetch_assoc()) {
                       
                        echo '<tr">';
                        echo "<td>" . $row['id_pedido'] . "</td>";
                        echo "<td>" . $row['nombre_pizza'] . "</td>";
                        echo "<td>" . $row['cantidad'] . "</td>";
                        echo "<td>" . $row['descripcion'] . "</td>";
                        echo "<td>" . $row['precio_pizza'] . "</td>";
                        echo "</tr>";      
                    }
                    echo "</tbody>";
                    echo "</table>";
                }  else { ?>
                    <p>Error</p>
                <?php }
                ?>
                <h4>PRECIO TOTAL: <?php echo $pret ?></h4>
                <p><a href="../VIEW/pedidos.php" class="titulo btn btn-success">Retroceder</a></p>
                <?php

                mysqli_close($link); ?>
            </div>
        </div>
    </section>

</body>

</html>