<?php
// include database configuration file
include '..\CONTROLLER\config.php';

// initializ shopping cart class
include 'cart.php';
$cart = new Cart;

// redirect to home if cart is empty
if ($cart->total_items() <= 0) {
    header("Location: ../VIEW/index.php");
}

// set customer ID in session
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    $_SESSION['sessCustomerID'] = $_SESSION["id_user"];
}
$nsnombre = $nstelefono = $nscorreo = $nsdireccion = "";
$nsnombre_err = $nstelefono_err = $nscorreo_err = $nsdireccion_err = "";
// get customer details by session customer ID
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    $query = $link->query("SELECT * FROM usuarios WHERE id_user = " . $_SESSION['sessCustomerID']);
    $custRow = $query->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<?php require_once '../VIEW/header.php'; ?>
<head>
    <title>Checkout - PHP Shopping Cart Tutorial</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../VIEW/CSS/style1.css">
    <link rel="stylesheet" href="../VIEW/CSS/contact.css">
    <style>
        .checko{
            color: black;
        }
        .datos{
            align-content: center;
        }
    </style>
</head>

<body>
    <section class="contenedor">
        <div class="checko">
            <div class="container">
                <h1>Vista del pedido</h1>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($cart->total_items() > 0) {
                            //get cart items from session
                            $cartItems = $cart->contents();
                            foreach ($cartItems as $item) {
                        ?>
                                <tr>
                                    <td><?php echo $item["name"]; ?></td>
                                    <td><?php echo '$' . $item["price"] . ' CLP'; ?></td>
                                    <td><?php echo $item["qty"]; ?></td>
                                    <td><?php echo '$' . $item["subtotal"] . ' CLP'; ?></td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="4">
                                    <p>El carrito esta vacio......</p>
                                </td>
                            <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"></td>
                            <?php if ($cart->total_items() > 0) { ?>
                                <td class="text-center"><strong>Total <?php echo '$' . $cart->total() . ' CLP'; ?></strong></td>
                            <?php } ?>
                        </tr>
                    </tfoot>
                </table>
                <div class="datos">
                    <?php
                    if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) { ?>
                        <h4>Detalles de envio</h4>
                        <p><?php echo $custRow['nombre_user']; ?></p>
                        <p><?php echo $custRow['correo']; ?></p>
                        <p><?php echo $custRow['telefono']; ?></p>
                        <p><?php echo $custRow['direccion']; ?></p>
                    <?php
                    } else { ?>
                        <h1 class="titulo">No tienes cuenta? Create una!! Es gratis Y Sumas puntos <a href="../CONTROLLER/register.php">Click Aqui</a></h1>
                        <!-- <div>
                    <label>Nombre</label>
                    <input type="text" name="nsnombre" class="form-control <?php echo (!empty($nsnombre_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $nsnombre; ?>">
                    <span class="invalid-feedback"><?php echo $nsnombre_err; ?></span>
                </div>
                <div>
                    <label>Telefono</label>
                    <input type="text" name="nsnombre" class="form-control <?php echo (!empty($nstelefono_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $nstelefono; ?>">
                    <span class="invalid-feedback"><?php echo $nstelefono_err; ?></span>
                </div>
                <div>
                    
                    <label>Correo</label>
                    <input type="text" name="nsnombre" class="form-control <?php echo (!empty($nscorreo_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $nscorreo; ?>">
                    <span class="invalid-feedback"><?php echo $nscorreo_err; ?></span>
                </div>
                <div>
                    
                    <label>Direccion</label>
                    <input type="text" name="nsnombre" class="form-control <?php echo (!empty($nsdireccion_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $nsdireccion; ?>">
                    <span class="invalid-feedback"><?php echo $nsdireccion_err; ?></span>
                </div>
                <div>
                    <h4 class="letra">Medio De Pago:</h4>
                    <label><input type="radio" name="tipopago"> Efectivo</label>
                    <label><input type="radio" name="tipopago"> Debito/Credito</label>
                    <label><input type="radio" name="tipopago"> Transferencia</label>
                </div> -->

                    <?php } ?>
                </div>
                <div class="footBtn">
                    <a href="../VIEW/index.php" class="btn btn-warning"><i class="glyphicon glyphicon-menu-left"></i> Continuar Comprando</a>
                    <?php if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){ ?>
                    <a href="cartAction.php?action=placeOrder" class="btn btn-success orderBtn">Enviar Pedido <i class="glyphicon glyphicon-menu-right"></i></a>
                    <?php } ?>
                </div>
            </div>
    </section>
</body>

</html>