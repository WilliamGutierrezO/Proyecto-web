<?php
   require_once 'config.php';
   // USUARIO
   $sql = "CREATE SCHEMA usmpizza IF NOT EXISTS";
   if ($conn->query($sql)===TRUE){
      echo "Tabla Creada.";
      echo "<br>";
   } else {
      die("ERROR EN CREAR TABLA: " . $conn->error);
   }
   
   $sql = "CREATE TABLE usuarios (
      id_user INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      username VARCHAR(50) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      rol INT(1) DEFAULT 2 NOT NULL,
      rut VARCHAR(10) NOT NULL,
      nombre VARCHAR(50) NOT NULL,
      telefono VARCHAR(20) NOT NULL,
      correo VARCHAR(50) NOT NULL,
      direccion VARCHAR(50) NOT NULL
   )";
   if ($conn->query($sql)===TRUE){
      echo "Tabla Creada.";
      echo "<br>";
   } else {
      die("ERROR EN CREAR TABLA: " . $conn->error);
   }
   

   // PEDIDO
   $sql = "CREATE TABLE pedido(
      id_pedido INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      fecha DATETIME DEFAULT(GetDate()),
      medio_pago tinyint(1) NOT NULL,
      precio_total int(7) NOT NULL
   )";
     if ($conn->query($sql)===TRUE){
      echo "Tabla Creada.";
      echo "<br>";
   } else {
      die("ERROR EN CREAR TABLA: " . $conn->error);
   }
  
   //PIZZA
    $sql = "CREATE TABLE pizzas (
      id_pizza INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      nombre_pizza VARCHAR(50) NOT NULL,
      precio_pizza INT(6) NOT NULL,
      descripcion VARCHAR(100) NOT NULL
   )";
   if ($conn->query($sql)===TRUE){
      echo "Tabla Creada.";
      echo "<br>";
   } else {
      die("ERROR EN CREAR TABLA: " . $conn->error);
   }
   //DETALLE_PEDIDO
      $sql = "CREATE TABLE detalle_pedido(
         id_pedido INT NOT NULL AUTO_INCREMENT,
         id_pizza INT,
         precio_pizza INT NOT NULL,
         cantidad INT 
      )";
    if ($conn->query($sql)===TRUE){
      echo "Tabla Creada.";
      echo "<br>";
   } else {
      die("ERROR EN CREAR TABLA: " . $conn->error);
   }

   //DETALLE_PIZZA(CREADA)
   $sql = "CREATE TABLE detalle_pizza(
      id_pizza INT NOT NULL AUTO_INCREMENT,
      id_ingredientes INT
   )";
   if ($conn->query($sql)===TRUE){
   echo "Tabla Creada.";
   echo "<br>";
   } else {
   die("ERROR EN CREAR TABLA: " . $conn->error);
   }

   $sql = "CREATE TABLE ingredientes(
      id_ingrediente INT NOT NULL AUTO_INCREMENT,
      nombre_ingredientes VARCHAR(20),
      precio_ingredientes INT

   )";
   if ($conn->query($sql)===TRUE){
   echo "Tabla Creada.";
   echo "<br>";
   } else {
   die("ERROR EN CREAR TABLA: " . $conn->error);
   }


   // INSERTAR ADMIN
   $sql = "INSERT INTO usuarios VALUES(0,1, '20782349-3', 'sdasdasd',2342424243,'example@gmail.com','av falsa 123')";
   if ($conn->query($sql)===TRUE){
        echo "ADMIN INGRESADO";
   }else{
    die("ERROR INGRESANDO ADMIN" . $conn->error);
   }
