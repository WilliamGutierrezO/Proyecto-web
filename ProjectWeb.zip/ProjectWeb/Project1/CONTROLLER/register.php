<?php
// Include config file
require_once "config.php";
// Define variables and initialize with empty values
$username = $password = $confirm_password = $nombre = $telefono = $correo = $direccion = "";
$username_err = $password_err = $confirm_password_err = $nombre_err = $telefono_err = $correo_err = $direcc_err =  "";
// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } elseif (!preg_match(
        '/^[a-zA-Z0-9_]+$/',
        trim($_POST["username"])
    )) {
        $username_err = "El nombre de usuario solo puede contener letras, numeros y guion bajo.";
    } else {
        // Prepare a select statement
        $sql = "SELECT id_user FROM usuarios WHERE username = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param(
                $stmt,
                "s",
                $param_username
            );
            // Set parameters
            $param_username = trim($_POST["username"]);
            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $username_err = "El nombre de usuario ya esta en uso.";
                } else {
                    $username = trim($_POST["username"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Por favor ingrese una contraseña.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "La contraseña debe tener al menos 6 caracteres.";
    } else {
        $password = trim($_POST["password"]);
    }
    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Por favor confirme contraseña.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Las Contraseñas no coinciden.";
        }
    }
    // Check input errors before inserting in database
    

    if (empty(trim($_POST["nombre"]))) {
        $nombre_err = "Por favor ingrese un nombre.";
    } elseif (!preg_match(
        '/^[a-zA-Z]+$/',
        trim($_POST["nombre"])
    )) {
        $nombre_err = "El nombre solo puede contener letras";
    }else{
        $nombre = trim($_POST["nombre"]);
    }

    if (empty(trim($_POST["telefono"]))) {
        $telefono_err = "Por favor ingrese su nombre de usuario.";
    } elseif (!preg_match(
        '/^[0-9]+$/',
        trim($_POST["telefono"])
    )) {
        $telefono_err = "El telefono solo puede contener numeros";
    }else{
        $telefono = trim($_POST["telefono"]);
    }


    if (empty(trim($_POST["correo"]))) {
        $correo_err = "Please enter an e-mail.";
    } elseif (!preg_match(
        '/^[A-Za-z0-9-_.+%]+@[A-Za-z0-9-.]+.[A-Za-z]{2,4}$/',
        trim($_POST["correo"])
    )) {
        $correo_err = "El formato del correo no es correcto";
    }else{
        // Prepare a select statement
        $sql = "SELECT id_user FROM usuarios WHERE correo = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param(
                $stmt,
                "s",
                $param_correo
            );
            // Set parameters
            $param_correo = trim($_POST["correo"]);
            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                /* store result */
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $correo_err = "Este Correo ya esta en uso";
                } else {
                    $correo = trim($_POST["correo"]);
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
        


    if (empty(trim($_POST["direccion"]))) {
        $direcc_err = "Por favor ingrese su direccion.";
    } elseif (!preg_match(
        '/^[a-zA-Z]+$/',
        trim($_POST["direccion"])
    )) {
        $direcc_err = "";
    }else{
        $direccion = trim($_POST["direccion"]);
    }



    if (
        empty($username_err) && empty($password_err) && empty($confirm_password_err) && empty($nombre_err) && empty($telefono_err) && empty($correo_err) && empty($direcc_err)
    ) {
        // Prepare an insert statement
        $sql = "INSERT INTO usuarios(username, password, nombre_user, telefono, correo, direccion) VALUES(?, ?, ?, ?, ?, ?)";
        if ($stmt = mysqli_prepare($link, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param(
                $stmt,
                "ssssss",
                $param_username,
                $param_password,
                $param_nombre,
                $param_telefono,
                $param_correo,
                $param_direccion
            );
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_nombre = $nombre;
            $param_telefono = $telefono;
            $param_correo = $correo;
            $param_direccion = $direccion;
            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                // Redirect to login page
                header("location: ../VIEW/login-view.php");
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            // Close statement
            mysqli_stmt_close($stmt);
        }
    }


    // Close connection
    mysqli_close($link);




}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../VIEW/CSS/style.css">
</head>

<body>
    <div class="wrapper">
        <h2 class="titulo">Registrarse</h2>
        <p class="letras">Favor llenar los siguientes datos para completar el registro.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="letras form-group">
                <label >Usuario</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ?'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>
            <div class="letras form-group">
                <label>Contraseña</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="letras form-group">
                <label>Confirmar Contraseña</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err))? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password;?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
          
            <div class="letras form-group">
                <label>Nombre</label>
                <input type="text" name="nombre" class="form-control <?php echo (!empty($nombre_err)) ?'is-invalid' : ''; ?>" value="<?php echo $nombre; ?>">
                <span class="invalid-feedback"><?php echo $nombre_err; ?></span>
            </div>
            <div class="letras form-group">
                <label>Telefono de contacto</label>
                <input type="text" name="telefono" class="form-control <?php echo (!empty($telefono_err)) ?'is-invalid' : ''; ?>" value="<?php echo $telefono; ?>">
                <span class="invalid-feedback"><?php echo $telefono_err; ?></span>
            </div>
            <div class="letras form-group">
                <label>Correo</label>
                <input type="text" name="correo" class="form-control <?php echo (!empty($correo_err)) ?'is-invalid' : ''; ?>" value="<?php echo $correo; ?>">
                <span class="invalid-feedback"><?php echo $correo_err; ?></span>
            </div>
            <div class="letras form-group">
                <label>Direccion</label>
                <input type="text" name="direccion" class="form-control <?php echo (!empty($direcc_err)) ?'is-invalid' : ''; ?>" value="<?php echo $direccion; ?>">
                <span class="invalid-feedback"><?php echo $direcc_err; ?></span>
            </div>

            <div class="form-group">
                <input type="submit" class="submit btn" value="Registrarse">
                
            </div>
            <div>
                
            </div>
            <p>Ya tienes cuenta? <a href="../VIEW/login-view.php">Inicia Sesion Aqui!</a>.</p>
        </form>
    </div>
</body>

</html>